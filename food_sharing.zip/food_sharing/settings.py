import redis

r = redis.StrictRedis()
